/**
 * Created by andrew.yang on 4/20/2017.
 */
import {OthersComponent} from "./others.component";

export const othersRoutes=[
    {
        path:'',
        component:OthersComponent
    },
];