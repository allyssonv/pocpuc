import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-others',
    templateUrl: './others.component.html',
})
export class OthersComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }
}
