/**
 * Created by andrew.yang on 5/18/2017.
 */
export class Login {
    first_name:string;
    last_name:string;
    avatar?:string;
    title?:string;
}