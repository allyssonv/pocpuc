A Pen created at CodePen.io. You can find this one at https://codepen.io/AbstractRef/pen/XavqLP.

 Bootstrap Crud Data Table For Database with Modal Form